import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.preprocessing import StandardScaler
from sklearn.multioutput import MultiOutputRegressor
from catboost import CatBoostRegressor  # 使用CatBoost
from sklearn.metrics import r2_score, mean_squared_error
from joblib import dump, load
import os

# 1. 加载数据集
data = pd.read_csv('3000shujuji.csv')
X = data.filter(regex='x\d+')  # 提取x0-x49
y = data.filter(regex='y\d+')  # 提取y0-y5

# 2. 数据分割 (80%训练集，20%测试集)
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

# 3. 输入输出归一化处理
x_scaler = StandardScaler()
y_scaler = StandardScaler()
X_train_scaled = x_scaler.fit_transform(X_train)
X_test_scaled = x_scaler.transform(X_test)
y_train_scaled = y_scaler.fit_transform(y_train)
y_test_scaled = y_scaler.transform(y_test)

# 保存归一化模型
dump(x_scaler, 'x_scaler.pkl')
dump(y_scaler, 'y_scaler.pkl')

# 4. 定义CatBoost模型和超参数网格 (关键修改点)
# 使用MultiOutputRegressor包装CatBoostRegressor以处理多输出
base_model = CatBoostRegressor(
    iterations=100,
    learning_rate=0.1,
    depth=6,
    random_state=42,
    verbose=False,
    task_type="CPU"  # 确保使用CPU
)

model = MultiOutputRegressor(base_model)

param_grid = {
    'estimator__iterations': [100, 200],         # 树的数量
    'estimator__learning_rate': [0.01, 0.05],     # 学习率
    'estimator__depth': [3, 5, 7],                     # 树的最大深度
    'estimator__l2_leaf_reg': [1, 3],               # L2正则化
    'estimator__border_count': [32, 64],           # 边界数量
    'estimator__early_stopping_rounds': [50]            # 早停轮数
}

# 5. 网格搜索
grid_search = GridSearchCV(
    estimator=model,
    param_grid=param_grid,
    cv=5,
    n_jobs=-1,
    scoring='neg_mean_squared_error',
    verbose=1
)
grid_search.fit(X_train_scaled, y_train_scaled)

# 6. 保存最优超参数
best_params = grid_search.best_params_
# 移除estimator__前缀，只保留实际参数
cleaned_params = {k.replace('estimator__', ''): v for k, v in best_params.items()}
with open('best_params_catboost.txt', 'w') as f:
    f.write("Best Hyperparameters for CatBoost:\n")
    for key, value in cleaned_params.items():
        f.write(f"{key}: {value}\n")
print(f"Best hyperparameters saved to 'best_params_catboost.txt'")
print(f"Best parameters: {cleaned_params}")

# 7. 获取最优模型
best_model = grid_search.best_estimator_

# 8. 预测和反归一化
y_train_pred_scaled = best_model.predict(X_train_scaled)
y_test_pred_scaled = best_model.predict(X_test_scaled)
y_train_pred = y_scaler.inverse_transform(y_train_pred_scaled)
y_test_pred = y_scaler.inverse_transform(y_test_pred_scaled)

# 9. 评估模型
def evaluate_model(y_true, y_pred, set_name):
    results = {}
    for i in range(y_true.shape[1]):
        r2 = r2_score(y_true.iloc[:, i], y_pred[:, i])
        mse = mean_squared_error(y_true.iloc[:, i], y_pred[:, i])
        results[f'y{i}'] = {'R2': r2, 'MSE': mse}
    return pd.DataFrame(results).T

train_results = evaluate_model(y_train, y_train_pred, 'Train')
test_results = evaluate_model(y_test, y_test_pred, 'Test')

# 保存评估结果
train_results.to_csv('train_results.txt')
test_results.to_csv('test_results.txt')

# 10. 绘制散点图
output_names = y.columns
plt.figure(figsize=(15, 20))
for i in range(y.shape[1]):
    plt.subplot(3, 2, i + 1)
    # 训练集
    train_label = f'Train (R²: {train_results.iloc[i, 0]:.3f}, MSE: {train_results.iloc[i, 1]:.3f})'
    plt.scatter(y_train.iloc[:, i], y_train_pred[:, i], c='blue', alpha=0.5, label=train_label)
    # 测试集
    test_label = f'Test (R²: {test_results.iloc[i, 0]:.3f}, MSE: {test_results.iloc[i, 1]:.3f})'
    plt.scatter(y_test.iloc[:, i], y_test_pred[:, i], c='red', alpha=0.5, label=test_label)
    # y=x线
    min_val = min(y.iloc[:, i].min(), y_train_pred[:, i].min())
    max_val = max(y.iloc[:, i].max(), y_train_pred[:, i].max())
    plt.plot([min_val, max_val], [min_val, max_val], 'k--')
    plt.title(f'{output_names[i]} Prediction vs True')
    plt.xlabel('True Values')
    plt.ylabel('Predicted Values')
    plt.legend()
plt.tight_layout()
plt.savefig('scatter_plots.png', dpi=300)

# 11. 保存模型 (使用自定义文件名)
dump(best_model, 'catboost_model.pkl')